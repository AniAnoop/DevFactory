import "./Subbanner.css"

function Subbanner() {
    return <>
        <div className="page">
            <div className="row1">
                <label> Shopping Cart</label>
            </div>
            <div className="row2">
                <div className="row2_b1">
                    <button>Home </button>
                    <label>.</label>
                </div>
                <div className="row2_b2">
                    <button>Pages</button>
                    <label>.</label>
                </div>
                <div className="row2_b2">
                    <button>Shopping Cart </button>
                </div>
            </div>
        </div>
    </>
}
export default Subbanner; 